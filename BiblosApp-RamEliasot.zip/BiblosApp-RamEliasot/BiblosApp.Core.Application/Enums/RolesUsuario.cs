﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblosApp.Core.Application.Enums
{
    public enum RolesUsuario
    {
        Administrativo = 1,
        Cliente
    }
}
